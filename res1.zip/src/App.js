import React, { useState, useEffect } from "react";
import "./App.css";
import "aos/dist/aos.css";
import Aos from "aos";
import Navbar from "./components/Nav/NavBar";
import Top from "./components/content/Top";
import Footer from "./components/Footer/Footer";
import Services from "./components/content/Services";
import { ThreedCard } from "./components/ThreedCard";
import ProgressBar from "./components/ProgressBar";
import ContactForm from "./components/ContactForm";
import GlowingCircle from "./components/GlowingCircle";
function App() {
  const [spinner, setSpinner] = useState(true);
  useEffect(() => {
    setTimeout(() => setSpinner(false), 4000);
    Aos.init({ duration: 2000 });
  }, []);

  if (!spinner) {
    return (
      <React.Fragment>
        <header id="NAV">
          <Navbar />
        </header>
        <main className="content-display">
          <div className="inner-content">
            <Top />
            <ThreedCard />
            <Services />
            <ProgressBar />
            <ContactForm />
          </div>
          <footer>
            <Footer />
          </footer>
        </main>
      </React.Fragment>
    );
  } else {
    return <GlowingCircle />;
  }
}

export default App;
