import React from 'react'
import "./GlowingCircle.css"
const GlowingCircle = () => {
    return (
        <div className="GCbody">
            <div className="GCloader">
            </div>            
        </div>
    )
}

export default GlowingCircle
