import React from "react";
import "./Footer.css";
import Footerup from "./Footerup";

function Footer() {
  return (
    <div className="whole-footer">
      <div style={{ width: "100%", height: "60px" }}>
        <Footerup />
      </div>
      <div className="Footer-content">
        <p>
          <span>T</span>echotron
        </p>
        <div className="quick-links">
          <b>Quick links</b>
          <ul>
            <li>
              <a href="#NAV">Home</a>
            </li>
            <li>
              <a href="#about">About us</a>
            </li>
            <li>
              <a href="#stag">Services</a>
            </li>
            <li>
              <a href="/">Terms of Service</a>
            </li>
            <li>
              <a href="/">Privacy Policy</a>
            </li>
          </ul>
        </div>
      </div>
      <div className="footer-down">
        © Copyright <strong>Techotron</strong>. All Rights Reserved
        <p>
          {"Designed by "}
          <a href="/">Techotron</a>
        </p>
      </div>
    </div>
  );
}

export default Footer;
