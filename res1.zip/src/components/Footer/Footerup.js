import React from "react";
import "./Footerup.css";

function Footerup() {
  return (
    <div data-aos="flip-up" className="Footerup-class">
      <ul>
        <li>
          <a href="https://www.facebook.com/Techotron-111474787296293">
            <i className="fa fa-facebook" aria-hidden="true"></i>
          </a>
        </li>
        <li>
          <a href="https://www.instagram.com/techo_tron/">
            <i className="fa fa-twitter" aria-hidden="true"></i>
          </a>
        </li>
        <li>
          <a href="mailto:info@techotron.in">
            <i className="fa fa-google-plus" aria-hidden="true"></i>
          </a>
        </li>
        <li>
          <a href="https://www.linkedin.com/company/techotron/">
            <i className="fa fa-linkedin" aria-hidden="true"></i>
          </a>
        </li>
        <li>
          <a href="https://www.instagram.com/techo_tron/">
            <i className="fa fa-instagram" aria-hidden="true"></i>
          </a>
        </li>
      </ul>
    </div>
  );
}

export default Footerup;
