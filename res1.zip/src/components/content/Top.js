import React from "react";
import img1 from "./image1.jpg";
import img2 from "./image2.jpg";
import {
  MDBCarousel,
  MDBCarouselCaption,
  MDBCarouselInner,
  MDBCarouselItem,
  MDBView,
  MDBContainer,
} from "mdbreact";

function Top() {
  return (
    <MDBContainer
      style={{
        maxWidth: "100vw",
        padding: "0",
        marginBottom: "80px",
        maxHeight: "100vh",
      }}
    >
      <MDBCarousel
        activeItem={1}
        length={2}
        showControls={true}
        showIndicators={true}
        className="z-depth-1"
      >
        <MDBCarouselInner>
          <MDBCarouselItem
            itemId="1"
            style={{ backgroundColor: "#000", zIndex: "6" }}
          >
            <MDBView>
              <img
                className="d-block w-100"
                src={img1}
                alt="First slide"
                height="600vh"
                style={{ zIndex: "5" }}
              />
            </MDBView>
            <MDBCarouselCaption>
              <h3 className="h3-responsive">
                Dynamic and Interactive web application designs that bring out
                the uniqueness of your brand.
              </h3>
            </MDBCarouselCaption>
          </MDBCarouselItem>
          <MDBCarouselItem itemId="2">
            <MDBView>
              <img
                className="d-block w-100"
                src={img2}
                alt="Second slide"
                height="600vh"
              />
            </MDBView>
            <MDBCarouselCaption style={{ justifyContent: "center" }}>
              <h3 className="h3-responsive">
                Easy to use technology with perfect blend of innovation,
                designing and development.
              </h3>
            </MDBCarouselCaption>
          </MDBCarouselItem>
        </MDBCarouselInner>
      </MDBCarousel>
    </MDBContainer>
  );
}

export default Top;
// <section>
//       <div className="content">
//         <h2>ADD Content</h2>
//       </div>
//     </section>
