import React from "react";
import "./Services.css";

function Services() {
  return (
    <div id="stag" className="whole-service">
      <div data-aos="fade-down" className="service-container">
        <h1>SERVICES</h1>
        <p className="">
          Your website represents your brand online – it is an imporant factor
          on how your consumers perceive your business. Studies have shown the
          average consumer makes a decision within 10 seconds of visiting your
          website. We’ll help you create an online professional image that is
          sure to impress people on their first visit.
        </p>

        <div data-aos="fade-up" className="services">
          <div className="service-c">
            <i className="fa fa-mobile" aria-hidden="true"></i>
            <h4 className="stitle">APP DEVELOPMENT</h4>
            <p className="sdescription">
              In this tech saavy world, it has become significant for businesses
              to maintain a presence via mobile apps. We build creative real
              world Android and iOS applications custom tailored for your
              business with complete frontend and backend implementations.
            </p>
          </div>
          <div className="service-c">
            <i className="fa fa-line-chart" aria-hidden="true"></i>
            <h4 className="stitle">DIGITAL MARKETING</h4>
            <p className="sdescription">
              Digital marketing has become the most used marketing technology
              right now with advertising in websites, social media, search
              engines, emails and etc. We offer digital marketing services
              precisely for the nature of your business and make your business’s
              presence known in every digital medium.
            </p>
          </div>
          <div className="service-c">
            <i className="fa fa-code" aria-hidden="true"></i>
            <h4 className="stitle">WEB DEVELOPMENT</h4>
            <p className="sdescription">
              From company websites to campaign landing pages to e-commerce
              platforms, we design and develop high-end websites that are
              optimized for usability, speed and SEO partnering with you to know
              your preferences in designing a slick and organized website that
              creates a frictionless experience.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Services;
