import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import "./ContactForm.css";
// import {motion} from "framer-motion"

const ContactForm = () => {
  const [email, setEmail] = useState("");

  useEffect(() => {}, [email]);
  const sendmail = (e) => {};
  return (
    <>
      <Helmet>
        <meta name="viewport" content="width=device-width,initial-scale=1.0" />
        <link
          rel="stylesheet"
          href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
          integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN"
          crossorigin="anonymous"
        />
      </Helmet>
      <section className="CFcontact" id="contact">
        <div className="CFcontent">
          <h2>Contact Us</h2>
        </div>
        <div className="CFcontainer">
          <div className="CFcontactInfo">
            <div className="CFbox">
              <div className="CFicon">
                <i className="fa fa-map-marker" aria-hidden="true"></i>
              </div>
              <div className="CFtext">
                <h4>Address</h4>
                <p>
                  1/192,FATHIMA Nagar, Thumbaipatti-Melur,Madurai, Tamil
                  Nadu,625108.
                </p>
              </div>
            </div>
            <div className="CFbox">
              <div className="CFicon">
                <i className="fa fa-phone" aria-hidden="true"></i>
              </div>
              <div className="CFtext">
                <h4>Phone</h4>
                <a href="tel:+919345054094">
                  <p>+91 9345 0540 94</p>
                </a>
              </div>
            </div>
            <div className="CFbox">
              <div className="CFicon">
                <i className="fa fa-envelope-o" aria-hidden="true"></i>
              </div>
              <div className="CFtext">
                <h4>Email</h4>
                <a href="mailto:info@techotron.in">
                  <p className="CFlink">info@techotron.in</p>
                </a>
              </div>
            </div>
          </div>
          <div className="CFcontactForm">
            <form>
              <h2>Send Message</h2>
              <div className="CFinputBox">
                <input type="text" name="" required="required" />
                <span>Full Name</span>
              </div>
              <div className="CFinputBox">
                <input
                  type="text"
                  onChange={(e) => setEmail(e.target.value)}
                  required="required"
                />
                <span>Email</span>
              </div>
              <div className="CFinputBox">
                <textarea required="required" />
                <span>Type your Message....</span>
              </div>
              <div className="CFinputBox">
                <input type="submit" onClick={sendmail} value="Send" />
              </div>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactForm;
