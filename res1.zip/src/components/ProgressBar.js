import React from "react";
import "./ProgressBar.css";
const ProgressBar = () => {
  return (
    <React.Fragment>
      <h2 className="PBabout">OUR SKILLS</h2>
      <p className="PBdesc">Here some of the skills which we are expert in</p>
      <div className="PBbody">
        <div className="PBcontainer">
          <div data-aos="zoom-in" className="PBcard">
            <div className="PBbox">
              <div className="PBpercent">
                <svg className="PBsvg">
                  <circle cx="70" cy="70" r="70"></circle>
                  <circle cx="70" cy="70" r="70"></circle>
                </svg>
                <div className="PBnumber">
                  <h2>
                    100<span>%</span>
                  </h2>
                </div>
              </div>
              <h2 className="PBtext">Html</h2>
            </div>
          </div>

          <div data-aos="zoom-in" className="PBcard">
            <div className="PBbox">
              <div className="PBpercent">
                <svg className="PBsvg">
                  <circle cx="70" cy="70" r="70"></circle>
                  <circle cx="70" cy="70" r="70"></circle>
                </svg>
                <div className="PBnumber">
                  <h2>
                    100<span>%</span>
                  </h2>
                </div>
              </div>
              <h2 className="PBtext">CSS</h2>
            </div>
          </div>

          <div data-aos="zoom-in" className="PBcard">
            <div className="PBbox">
              <div className="PBpercent">
                <svg className="PBsvg">
                  <circle cx="70" cy="70" r="70"></circle>
                  <circle cx="70" cy="70" r="70"></circle>
                </svg>
                <div className="PBnumber">
                  <h2>
                    90<span>%</span>
                  </h2>
                </div>
              </div>
              <h2 className="PBtext">Javascript</h2>
            </div>
          </div>

          <div data-aos="zoom-in" className="PBcard">
            <div className="PBbox">
              <div className="PBpercent">
                <svg className="PBsvg">
                  <circle cx="70" cy="70" r="70"></circle>
                  <circle cx="70" cy="70" r="70"></circle>
                </svg>
                <div className="PBnumber">
                  <h2>
                    100<span>%</span>
                  </h2>
                </div>
              </div>
              <h2 className="PBtext">Java</h2>
            </div>
          </div>

          <div data-aos="zoom-in" className="PBcard">
            <div className="PBbox">
              <div className="PBpercent">
                <svg className="PBsvg">
                  <circle cx="70" cy="70" r="70"></circle>
                  <circle cx="70" cy="70" r="70"></circle>
                </svg>
                <div className="PBnumber">
                  <h2>
                    95<span>%</span>
                  </h2>
                </div>
              </div>
              <h2 className="PBtext">Node JS</h2>
            </div>
          </div>

          <div data-aos="zoom-in" className="PBcard">
            <div className="PBbox">
              <div className="PBpercent">
                <svg className="PBsvg">
                  <circle cx="70" cy="70" r="70"></circle>
                  <circle cx="70" cy="70" r="70"></circle>
                </svg>
                <div className="PBnumber">
                  <h2>
                    95<span>%</span>
                  </h2>
                </div>
              </div>
              <h2 className="PBtext">React JS</h2>
            </div>
          </div>

          <div data-aos="zoom-in" className="PBcard">
            <div className="PBbox">
              <div className="PBpercent">
                <svg className="PBsvg">
                  <circle cx="70" cy="70" r="70"></circle>
                  <circle cx="70" cy="70" r="70"></circle>
                </svg>
                <div className="PBnumber">
                  <h2>
                    75<span>%</span>
                  </h2>
                </div>
              </div>
              <h2 className="PBtext">Android</h2>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default ProgressBar;
