import React from "react";
import styled from "styled-components";

const Ul = styled.ul`
  list-style: none;
  display: flex;
  flex-flow: row nowrap;
  li {
    padding: 25px 15px;
  }
  li a {
    font-size: 100%;
    font-family: tahoma;
    font-weight: bold;
    text-decoration: none;
    color: mintcream;
  }
  li a:hover,
  li a:active {
    color: #b4153e;
  }
  @media (max-width: 768px) {
    flex-flow: column nowrap;
    background-color: #0d2538;
    position: fixed;
    transform: ${({ open }) => (open ? "translateX(0)" : "translateX(100%)")};
    top: 0;
    right: 0;
    height: 100vh;
    width: 45%;
    padding-left: 5%;
    padding-top: 3.5rem;
    transition: transform 0.3s ease-in-out;
    li {
      color: #fff;
    }
    li a {
      font-size: 100%;
    }
  }
`;

const RightNav = ({ open }) => {
  return (
    <Ul open={open}>
      <li>
        <a href="#NAV">Home</a>
      </li>
      <li>
        <a href="#about">About Us</a>
      </li>
      <li>
        <a href="#stag">Services</a>
      </li>
      <li>
        <a href="#contact">Contact Us</a>
      </li>
    </Ul>
  );
};

export default RightNav;
