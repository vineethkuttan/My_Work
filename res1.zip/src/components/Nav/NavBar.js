import React from "react";
import styled from "styled-components";
import Burger from "./Burger";
import techotron from "./techotron.png";

const Nav = styled.nav`
  position: fixed;
  width: 100%;
  height: 80px;
  top: 0;
  background: #ddd;
  z-index: 100000;
  border-bottom: 2px solid #f1f1f1;
  padding: 0 10px;
  display: flex;
  justify-content: space-between;
  .logo {
    width: 40%;
    min-width: 85px;
    max-width: 200px;
    height: 100%;
  }
`;

const Navbar = () => {
  return (
    <Nav>
      <div className="logo">
        <a href="/">
          <img src={techotron} alt="techotron" width="60%" height="80px" />
        </a>
      </div>
      <Burger />
    </Nav>
  );
};

export default Navbar;
