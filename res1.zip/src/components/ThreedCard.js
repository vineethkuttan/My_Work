import React from "react";
import mission from "./mission2.jpg";
import planning from "./planning2.jpg";
import vision from "./vision2.jpg";
import "./ThreedCard.css";
export const ThreedCard = () => {
  return (
    <>
      <div id="about" className="TCpbody">
        <div data-aos="slide-up" className="TCcontainercard">
          <h1 className="TCabout">ABOUT US</h1>
          <p className="TCdesc">
            A dedicated team to provide you high quality and cost effective Web
            development (Static & Dynamic), Android application development
            services. Scalable and secure application development is our forte.
          </p>

          <div className="TCcard">
            <div className="TCimgBx">
              <img src={planning} alt="mission" />
            </div>
            <div className="TCcontent">
              <p className="TChesp">OUR MISSION</p>
              <p className="TChes">
                We aim to provide customised solutions which make your business
                easier and results in ultimate user satisfaction. We strive to
                be in the forefront of innovations by adapting the latest
                technologies and update our implement our system from time to
                time.
              </p>
            </div>
          </div>

          <div className="TCcard">
            <div className="TCimgBx">
              <img src={mission} alt="planning" />
            </div>
            <div className="TCcontent">
              <p className="TChesp">OUR PLANS</p>
              <p className="TChes">
                We take immense efforts to understand your requirements & goals
                and offer strategic web & application solutions. We provide high
                quality solutions after thorough research and analysis based on
                the project and are always open to discussions on the project
                ideas.
              </p>
            </div>
          </div>

          <div className="TCcard">
            <div className="TCimgBx">
              <img src={vision} alt="vision" />
            </div>
            <div className="TCcontent">
              <p className="TChesp">OUR VISION</p>
              <p className="TChes">
                We aspire to be your ultimate growth partners through the
                incorporation of the latest technology thereby, maximizing your
                business value and consequently leading to the enlargement of
                your business on a larger scale.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
